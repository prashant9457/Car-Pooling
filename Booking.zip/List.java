public class List {
    private java.util.ArrayList<Object> items;

    public List() {
        items = new java.util.ArrayList<>();
    }

    public static void main(String[] args) {
        List list = new List();
        System.out.println("List created successfully!");
    }
}